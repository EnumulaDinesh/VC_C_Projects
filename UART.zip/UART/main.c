#include<lpc21xx.h>
#include<string.h>
extern void uart_init(void);
int data;
int i;
char buffer[];
char res[]="Dinesh";
char res1[]="Give correct input";
int main(){				
uart_init();
	while(1){
		for(i=0;i<7;i++)
		{
			while(!(U0LSR&0x01));
			buffer[i]=U0RBR;
		}	
		if(strcmp(buffer,"enumula")==0)
			{	i=0;
				while(res[i]!='\0')
				    {
									U0THR=res[i];
									i++;
									while(!(U0LSR&0x20));
				 }
			}
			
			U0THR='\n';
			while(!(U0LSR&0x20));
			
			if(strcmp(buffer,"enumula")!=0)
			{	i=0;
				while(res1[i]!='\0')
				    {
									U0THR=res1[i];
									i++;
									while(!(U0LSR&0x20));
				 }
				 U0THR='\n';
			while(!(U0LSR&0x20));
			}
}
}
