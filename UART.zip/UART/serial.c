#include<lpc21XX.h>
void uart_init(void)
{
	PINSEL0=0X05;
	U0LCR=0X83;
	U0DLL=97;
	U0LCR=0X03;
}
